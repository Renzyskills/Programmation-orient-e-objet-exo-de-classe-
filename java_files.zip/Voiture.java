package EXO1;

public class Voiture {
    public String marque;
    public String modele;
    public String couleur;

    public void demarrer () {
        System.out.println("La voiture a demarré !");
    }
}