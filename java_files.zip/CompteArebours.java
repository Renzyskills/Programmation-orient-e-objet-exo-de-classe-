public class CompteArebours {
    public static void main(String[] args) {
        System.out.println("Lancement !!");
        int compte = 10;
        while (compte >= 1) {
            System.out.println(compte);
            compte --;
        }
        System.out.println("Décollage");
    }
}